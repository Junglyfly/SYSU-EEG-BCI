This section will describe possible problems with the board.

1. If the boards has too high internal noise - check the power supply by multimeter in the next points- Baipas_CAP.txt

