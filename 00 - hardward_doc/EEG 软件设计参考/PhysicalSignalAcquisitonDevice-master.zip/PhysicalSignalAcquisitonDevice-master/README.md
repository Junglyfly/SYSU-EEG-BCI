# 生理电信号采集设备

a device for EEG and ECG measuring
2018 national undergraduate biomedical engineering innovation design competition

这是去年参加生物医学工程的比赛资料，是一个命题组的心脑电采集项目

用的ADC是ADS1299，MCU是STM32F103C8T6

当时这个东西做的很仓促，最后比赛也只是二等奖， 就不献丑了，pcb电路版图和代码就不放了（最后成品的噪声略高，效果不是非常好）
