## Firmware for OpenLD system
 - User configurable 8 channel datastream with 250SPS Sampling rate
 - IIR Bandpass Impedence monitor (unstable)
 - Terminal "GUI" interface for enabling and configuring channels

## This program is intended to be used with the OpenLD software for EEG brainwave analysis
